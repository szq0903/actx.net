>本编辑器仅可用于手机端，如有Bug反馈和建议请发送邮件至：try@fixel.cn
> ![image](https://eleditor.fixel.cn/static/eleditor/images/qrcode.png)

>QQ群: 567594992
>Eleditor其实是为了解决的内部一些特殊编辑需求而开发的一个编辑器，开源出来提供一个简单的富文本编辑方案，首先因为操作问题它并不适合所有业务场景

>文档地址[https://www.kancloud.cn/hihwp/eleditor/content/default.md](https://www.kancloud.cn/hihwp/eleditor/content/default.md)

目前编辑器还在持续维护，因本人精力有限，群里记录的问题可能本人不能及时回复，但每个问题和意见都会一一记录

开源基于MIT协议，允许自由使用和修改代码
